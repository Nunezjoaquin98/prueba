typedef struct{
int edad;
char nombre[20];
}Persona;

int preguntarSalir(void);





