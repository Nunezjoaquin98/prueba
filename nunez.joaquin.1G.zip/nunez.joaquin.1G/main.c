#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "biblotecaNunez.h"
#include "cliente.h"
#include "juegos.h"
#include "alquileres.h"
#define TAMc 15
#define TAMj 20
#define TAMa 150


// El hardcodeo de el juego y cliente estan en biblotecaNunez.h .

int main()
{

    int seguir = 1 ;
    int flagClientes = 0 ;
    int flagJuegos = 0;

    eCliente clientes[TAMc];
    eJuegos juegos[TAMj];
    eCategoria cat[6];
    eAlquiler alq[TAMa];
    eFecha fechaNueva[TAMa];

    initAlquiler(alq,TAMa);
    initClientes(clientes,TAMc) ;
    initJuegos(juegos,TAMj) ;
    harcodearCat(cat);
    harcodeoJuego(juegos);


    do
    {
        switch(menu())
        {
        case 1:
            // menu para dar de alta cliente modificar baja y listar.
            switch(menuClientes())
            {
            case 1://alta
                system("cls");
                addCliente(clientes,TAMc,flagClientes);
                break;
            case 2:// modificar
                system("cls") ;
                if(flagClientes)
                {
                    modifyCliente(clientes,TAMc) ;
                }
                else
                {
                    printf("\nError no hay clientes\n");
                    system("pause");
                }
                break;

            case 3://remover
                system("cls") ;
                if(flagClientes)
                {
                    removeCliente(clientes,TAMc);

                }
                else
                {
                    printf("\nError no hay clientes\n");
                    system("pause");

                }

                break;
            case 4:// listar
                system("cls") ;
                if(flagClientes)
                {

                    listarClientes(clientes,TAMc) ;
                    showClientes(clientes,TAMc) ;
                    system("pause") ;

                }
                else
                {
                    printf("\nError no hay clientes\n");
                    system("pause");
                }
            }
            break;
        case 2: // alquileres

            switch(menuAlquileres())
            {
            case 1:
                if(flagClientes)
                {
                    addAlquiler(alq,TAMa,fechaNueva,TAMa,clientes,TAMc,juegos,TAMj,cat,5);
                    system("cls") ;

                }
                else
                {
                    printf("\nError no hay clientes\n");
                    system("pause");
                }
                break;

            case 2:
                if(flagClientes)
                {
                    listarAlquileres(alq,TAMa);
                }
                else
                {
                    printf("\nError no hay clientes\n");
                    system("pause");

                }
            case 3:
            printf("\n\n\n Saliendo..\n\n") ;
            system("pause") ;
            break;
            default:
                printf("\n\n Debe ingresar un numero del 1 al 3.\n\n");
                system("pause");
                break;
            }
            break;
        case 3:// juegos
            switch(menuJuegos())
            {
            case 1:
                addJuego(juegos,TAMj,cat,5,flagJuegos);
                break ;
            case 2:
                modifyJuego(juegos,TAMj,cat,TAMc);
                break;
            case 3:
                removeJuegos(juegos,TAMj);
                break;
            case 4:
                showJuegos(juegos,TAMj);
                break;
            default:
                printf("\n\n Debe ingresar un numero del 1 al 4.\n\n");
                system("pause");
                break;

            }
        case 4:
            switch(menuInformes())
            {
            case 1:
                showJuegosDeMesa(juegos,TAMj);
                system("pause");
                break;
            case 2:
                clientesNoAlquilaron(alq,TAMa,clientes,TAMc,juegos,TAMj);
                break;
            }
        case 5:
            printf("\n\n\n Saliendo..\n\n") ;
            system("pause") ;
            seguir = 0 ;
            break;
        default:
            printf("\n\n Debe ingresar un numero del 1 al 4.\n\n");
            system("pause");
            break;
        }
    }
    while(seguir) ;

    return 0;
}


