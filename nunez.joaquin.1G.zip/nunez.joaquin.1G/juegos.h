typedef struct
{
    int id;
    char descripcion[51] ;
}eCategoria;

typedef struct
{
    int codigo ;
    char descripcion[51];
    double importe;
    int idCategoria;
    int isEmpty;
}eJuegos;

/** \brief busca un indice libre
 *
 * \param array de juegos
 * \param  tamanio del array juegos
 * \return indice
 *
 */

int searchEmptyJuegos(eJuegos list[],int len) ;

/** \brief inicializa todos los juegos en true en la bandera
 *
 * \param  array de juegos a cargar
 * \param  int tamanio del array
 *
 */
void initJuegos(eJuegos list[],int len) ;

/** \brief muestra un array
 *
 * \param array a mostrar
 */
void showJuego(eJuegos list) ;

/** \brief muestra todos los elementos de un array
 *
 * \param array a recorrer
 * \param tamanio del array
 *
 */
void showJuegos(eJuegos list[],int len) ;


/** \brief se carga 5 juegos en la estructura cuando se llama a esta funcion
 *
 * \param array de la estructura a cargar
 *
 */
void harcodeoJuego(eJuegos list[]) ;

/** \brief se carga 5 categorias en la estructura cuando se llama a esta funcion
 *
 * \param array de la estructura a cargar
 *
 */
void harcodearCat(eCategoria list[]) ;

/** \brief muestra todos los elementos de un array
 *
 * \param array a recorrer
 * \param tamanio del array
 *
 */
void showCategorias(eCategoria list[], int len) ;


/** \brief se ingresa el codigo del juego y lo encuentra
 *
 * \param array a recorrer
 * \param tama�o del array
 * \param codigo a buscar
 * \return Return juego index position or (-1) if the cliente not found.
 */
int findJuegoByCode(eJuegos list[], int len, int code);


/** \brief  muestra todos los juegos con categoria 5
 *
 * \param array de juegos
 * \param tamanio del array
 *
 */
void showJuegosDeMesa(eJuegos list[], int len);


/** \brief crea un nuevo juego
 * \param list juegos
 * \param len int tam
 * \param list categoria
 * \param len int t
* \return (-1) if Error [Invalid length or NULL pointer or without
 * free space] - (0) if Ok
*/
int addJuego(eJuegos list[],int len,eCategoria listC[],int lenC,int flagJuegos) ;


/** \brief modifica un juego
 *
 * \param array de juego
 * \param tama�o del array
 *
 */
void modifyJuego(eJuegos list[], int len,eCategoria listC[],int lenC) ;


/** \brief menu de alta baja modificar y listar juegos
 *
 * \return opcion elejida
 *
 */
int menuJuegos ( ) ;


/** \brief da de baja el juego
 *
 * \param array de juego a borrar
 * \param tamanio del array
 * \return  -1 si no encuentra juego 0 si ok
 *
 */
int removeJuegos(eJuegos list[], int len);
