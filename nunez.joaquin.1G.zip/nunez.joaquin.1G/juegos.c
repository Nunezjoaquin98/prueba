#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "biblotecaNunez.h"
#include "juegos.h"

int menuJuegos ( )
{
    char auxOption[2];
    int option;
    system("cls") ;
    printf("\n*** JUEGOS ***\n\n");
    printf("1 - ALTAS\n");
    printf("2 - MODIFICAR\n") ;
    printf("3 - BAJA\n") ;
    printf("4 - LISTAR\n") ;
    printf("5 - SALIR DE JUEGOS\n") ;
    while(!function_getStringNumeros("Ingresar opcion: ",auxOption))
    {
        printf("\n*** ERROR *** Debe ingresar un numero del 1 al 5. \n") ;
        system("pause") ;

    }
    option = atoi(auxOption) ;
    return option;
}

int searchEmptyJuegos(eJuegos list[],int len)
{
    int index = -1;
    for(int i=0; i< len ; i++)
    {
        if( list[i].isEmpty == 1)
        {
            index = i ;
            break;
        }
    }
    return index ;
}

void initJuegos(eJuegos list[],int len)
{
    for(int i=0; i < len; i++)
    {

        list[i].isEmpty = 1;
    }
}


void showJuego(eJuegos list)
{
    printf("\n %d\t\t%s\t\t\t%2.f\t\t%d\n",list.codigo,list.descripcion,list.importe,list.idCategoria);
}


void showJuegos(eJuegos list[],int len)
{
    system("cls");
    printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
    for(int i=0; i<len; i++)
    {
        if(list[i].isEmpty == 0);
        showJuego(list[i]) ;
    }
}

void harcodeoJuego(eJuegos list[])
{

    eJuegos x[]=
    {
        {212,"FIFA 19 PC",2999,3,0},
        {042,"Fornite PC",300,4,0},
        {113,"GTA 5 PC",1500,6,0},
        {404,"Call of Duty PC",1700,2,0},
        {10,"Monopoly",1100,5,0},
        {7,"Ludo",700,5,0},
        {9,"Adivina quien",1100,5,0},
        {5,"Juego de la Oca",1100,5,0},
        {23,"Generala",1100,5,0},
        {15,"Maincraft PC",2000,6,0}
    };
    for(int i = 0; i< 10; i++)
    {
        list[i] = x[i];
    }
}

int findJuegoByCode(eJuegos list[], int len, int code)
{
    int ret = -1;
    for(int i=0; i < len; i++)
    {

        if( list[i].codigo == code && list[i].isEmpty == 0)
        {
            ret = i;
            break;
        }
    }
    return ret;

}

void harcodearCat(eCategoria list[])
{
    eCategoria x[]=
    {
        {1, "Accion"},
        {2, "Disparos"},
        {3, "Deportes"},
        {4, "Supervivencia"},
        {5, "Juegos de mesa"},
        {6, "Mundo Abierto"}
    };

    for(int i=0; i < 5; i++)
    {
        list[i] = x[i];
    }
}

void showCategorias(eCategoria list[], int len)
{
    printf("\nLista de Categorias\n\n");

    for(int i=0; i < len; i++)
    {
        printf(" %d  %10s\n",list[i].id, list[i].descripcion);
    }
    printf("\n\n");
}

int addJuego(eJuegos list[],int len,eCategoria listC[],int lenC,int flagJuegos)
{
    eJuegos nuevoJuego;
    int ret;
    int index ;
    char auxDescripcion[21];
    char auxCategoria[3];
    char auxImporte[10] ;


    if(list != NULL && len > 0)
    {
        system("cls");
        fflush(stdin);
        index = searchEmptyJuegos(list,len) ;
        printf("\n------- Alta de Juego -------\n\n");

        if(index == -1)
        {
            printf("No hay lugar en el sistema. \n") ;
            ret = -1 ;
            system("pause");

        }
        else
        {

            index++;
            printf("\n Nuevo juego, codigo numero %d \n\nIngrese nombre del juego: ",index) ;
            gets(auxDescripcion);
            printf("\n\nSelecionar categoria:\n");
            showCategorias(listC,lenC);
            if(!function_getStringNumeros("Ingrese el codigo de la categoria que quiera elegir: ",auxCategoria))
            {
                printf("\nError, debe ingresar un numero.\n\n");
                system("pause");
                system("cls");
            }
            else if(!function_getStringNumeroFlotante("Ingrese el importe del juego: ",auxImporte))
            {
                printf("\nEl importe no debe tener letras.\n\n");
                system("pause");
                system("cls");
            }
            else
            {
                nuevoJuego.codigo = index ;
                strcpy(nuevoJuego.descripcion,auxDescripcion) ;
                nuevoJuego.idCategoria = atoi(auxCategoria) ;
                nuevoJuego.importe = atof(auxImporte);
                nuevoJuego.isEmpty = 0;
                list[index] = nuevoJuego ;
                system("pause");
                system("cls");
                printf("\n\nJUEGO DADO DE ALTA CON EXITO:\n\n");
                showJuego(list[index]);
                flagJuegos = 1 ;
                printf("\n\n\n");
                system("pause");
                ret = 0 ;
            }
        }

    }
    else
    {
        ret = -1 ;
    }
    return ret;
}


void modifyJuego(eJuegos list[], int len,eCategoria listC[],int lenC)
{
    int code;
    int index;
    int option;
    char auxOption[3];
    char auxCode[5];
    char newCategoria[5];
    char newName[51] ;
    char newImporte[3] ;
    char seguir = 's';


    system("cls");
    printf("  *** Modificar  Juego ***\n\n");
    showJuegos(list,len);

    if(!function_getStringNumeros("\nIngrese el codigo del juego a modificar: ",auxCode))
    {
        printf("*** ERROR *** El codigo debe contener solo numeros.") ;
    }

    code = atoi(auxCode) ;
    index = findJuegoByCode(list,len,code) ;


    if( index == -1)
    {
        printf("No hay ningun juego con el codigo %d.\n\n",code);
        system("pause");
    }
    else
    {

        do
        {
            system("cls");
            printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
            showJuego(list[index]) ;
            if(!function_getStringNumeros("\n\nQue desea modificar?\n\n1 - Descripcion\n2 - Importe\n3 - Categoria\n\n4 - Volver al menu\n\nIngrese numero: ",auxOption))
            {
                printf("Error debe ingresar un numero");
            }
            else
            {
                option = atoi(auxOption);
            }

            switch(option)
            {


            case 1:
                printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
                showJuego(list[index]) ;
                //modificar nombre
                printf("Ingrese nueva descripcion: ");
                       strcpy(list[index].descripcion,newName);
                       printf("\n\n        ***Modificacion exitosa***\n\n");
                       system("pause");
                       break;
                   case 2:
                           printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
                           showJuego(list[index]) ;
                           if(!function_getStringNumeros("Ingrese nuevo importe: ",newImporte))
                {
                    printf("*** ERROR *** El importe no puede tener letras.") ;
                    }
                    else
                    {

                        list[index].importe = atof(newImporte);
                        printf("\n\n        ***Modificacion exitosa***\n\n");
                        system("pause");
                    }
                break ;
            case 3:

                    // modifica importe
                    printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
                    showJuego(list[index]) ;
                    printf("\n\n");
                    showCategorias(listC,lenC);
                    if(!function_getStringNumeros("Ingrese nueva categoria: ",newCategoria))
                {
                    printf("*** ERROR *** La categoria debe contener solo numeros.") ;
                    }
                    else
                    {
                        list[index].idCategoria = atoi(newCategoria);
                        printf("\n\n        ***Modificacion exitosa***\n\n");
                        system("pause");
                    }
                break ;
            case 4:
                    printf("Salindo\n\n");
                    system("pause");
                    seguir = 'n';
                             break;
                         default:
                                 printf("*** ERROR *** Debe ingresar un numero del 1 al 4.\n");
                                 system("pause");
                                 break;
                    }
        }
        while(seguir == 's');
    }
}

void showJuegosDeMesa(eJuegos list[], int len)
{
    printf("TODOS LOS JUEGOS SON : \n\n\n");
    showJuegos(list,len);
    printf("\n Los juegos con categoria de mesa:\n");
    printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");

    for(int i=0; i<len; i++)
    {
        if(list[i].idCategoria == 5)
        {
            showJuego(list[i]) ;

        }

    }
}


int removeJuegos(eJuegos list[], int len)
{
    int index;
    int ret ;
    int codeFinal;
    char code[10] ;
    char seguir[1];

    if(list != NULL && len > 0)
    {
        system("cls");
        printf("  *** Baja Juego ***\n\n");

        printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
        showJuegos(list,len);
        if(!function_getStringNumeros("Ingrese codigo del juego: ",code))
        {
            printf("*** ERROR *** El codigo debe contener solo numeros.\n\n");
            system("pause") ;
            system("cls");
        }
        else
        {

            codeFinal = atoi(code) ;
            index = findJuegoByCode(list,len,codeFinal);


            if(index == -1)
            {
                printf("No hay ningun juego con codigo %d",codeFinal) ;
            }
            else
            {
                ret = 0;
                printf("\n\nCODIGO\t\tNOMBRE\t\t\tIMPORTE\t\tCATEGORIA\n\n");
                showJuego(list[index]) ;
                function_continueYesOrNo("\nConfima borrado s/n: ",seguir);
                if(seguir[0] == 'n' || seguir[0] == 'N')
                {
                    printf("Baja cancelada\n\n");
                }
                else
                {

                    list[index].isEmpty = 1;
                    printf("Borrado exitoso\n\n");
                }
                system("pause");
            }
        }
    }
    return ret ;
}


